# Henotace AI Python SDK

Official Python SDK for the Henotace AI API - your gateway to AI-powered tutoring and educational assistance.

## Features

- **Easy Integration**: Simple, intuitive API for Python applications
- **Session Management**: Built-in support for managing student sessions and chat history
- **Flexible Storage**: Support for in-memory and custom storage connectors
- **Async Support**: Full async/await support for modern Python applications
- **Error Handling**: Comprehensive error handling with custom exceptions
- **Rate Limiting**: Built-in retry logic and rate limit handling
- **Context Management**: Support for persistent context, personas, and user profiles

## Installation

```bash
pip install henotace-ai
```

Or install from source:

```bash
git clone https://github.com/henotace/henotace-python-sdk.git
cd henotace-python-sdk
pip install -e .
```

## Quick Start

### Basic Usage (Programmatic)

```python
import asyncio
from henotace_ai import HenotaceAI, create_tutor

async def main():
    # Initialize the SDK
    sdk = HenotaceAI(api_key="your_api_key_here")
    
    # Check API status
    if sdk.get_status_ok():
        print("✅ API is available")
    else:
        print("❌ API is not available")
        return
    
    # Create a tutor
    tutor = await create_tutor(
        sdk=sdk,
        student_id="student_123",
        tutor_name="Math Tutor",
        subject={"id": "math", "name": "Mathematics", "topic": "Algebra"}
    )
    
    # Send a message
    response = await tutor.send("Can you help me solve 2x + 5 = 13?")
    print(f"AI Response: {response}")
    
    # Continue the conversation
    response = await tutor.send("What's the first step?")
    print(f"AI Response: {response}")

# Run the example
asyncio.run(main())
```

### CLI Usage

Install editable and expose CLI:

```bash
pip install -e .[dev]
```

Then run:

```bash
export HENOTACE_API_KEY=your_key
henotace "Explain Pythagoras theorem"
```

Interactive REPL:

```bash
henotace
```

Options:

```bash
henotace --student-id stu1 --tutor-name math --persona "You are a patient math tutor" "Solve x+2=5"
```

### Advanced Usage with Context and Persona

```python
import asyncio
from henotace_ai import HenotaceAI, create_tutor, SessionSubject

async def advanced_example():
    sdk = HenotaceAI(api_key="your_api_key_here")
    
    # Create a specialized tutor
    tutor = await create_tutor(
        sdk=sdk,
        student_id="student_456",
        tutor_name="Physics Tutor",
        subject=SessionSubject(
            id="physics",
            name="Physics",
            topic="Mechanics"
        ),
        grade_level="high_school",
        language="en"
    )
    
    # Set persona and context
    tutor.set_persona("You are an enthusiastic physics tutor who loves to use real-world examples and analogies to explain complex concepts.")
    tutor.set_context([
        "The student is in 11th grade and is learning about Newton's laws.",
        "They prefer visual explanations and step-by-step problem solving."
    ])
    
    # Set user profile
    tutor.set_user_profile({
        "name": "Alex",
        "grade": "11th",
        "learning_style": "visual",
        "difficulty_level": "intermediate"
    })
    
    # Start tutoring session
    response = await tutor.send(
        "I'm confused about Newton's second law. Can you explain it?",
        context="We just covered Newton's first law in the previous lesson."
    )
    print(f"Tutor: {response}")
    
    # Check chat history
    history = tutor.history()
    print(f"Chat history has {len(history)} messages")

asyncio.run(advanced_example())
```

### Custom Storage Connector

```python
import asyncio
from henotace_ai import HenotaceAI, create_tutor, StorageConnector, SessionStudent, SessionTutor, SessionChat

class FileStorageConnector(StorageConnector):
    """Example custom storage connector that saves to JSON files"""
    
    def __init__(self, file_path="sessions.json"):
        self.file_path = file_path
        self.data = {"students": []}
        self._load()
    
    def _load(self):
        try:
            import json
            with open(self.file_path, 'r') as f:
                self.data = json.load(f)
        except FileNotFoundError:
            self.data = {"students": []}
    
    def _save(self):
        import json
        with open(self.file_path, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    def list_students(self):
        return [SessionStudent(**s) for s in self.data.get("students", [])]
    
    def upsert_student(self, student):
        students = self.data.get("students", [])
        # Implementation here...
        self._save()
    
    # Implement other required methods...

async def custom_storage_example():
    sdk = HenotaceAI(api_key="your_api_key_here")
    
    # Use custom storage
    storage = FileStorageConnector("my_sessions.json")
    
    tutor = await create_tutor(
        sdk=sdk,
        student_id="student_789",
        storage=storage
    )
    
    response = await tutor.send("Hello, I need help with chemistry!")
    print(f"Response: {response}")

asyncio.run(custom_storage_example())
```

## API Reference

### HenotaceAI

Main client for interacting with the Henotace AI API.

#### Methods

- `get_status()` - Check API status
- `get_status_ok()` - Quick status check (returns bool)
- `complete_chat(history, input_text, preset)` - Send chat completion request

### Tutor

Lightweight tutor instance for managing chat sessions.

#### Methods

- `send(message, context, preset)` - Send message to tutor
- `set_context(context)` - Set persistent context
- `set_persona(persona)` - Set tutor persona
- `set_user_profile(profile)` - Set user profile
- `set_metadata(metadata)` - Set metadata
- `history()` - Get chat history
- `compress_history()` - Compress old chat history

### StorageConnector

Abstract base class for storage implementations.

#### Built-in Implementations

- `InMemoryConnector` - In-memory storage for testing

## Configuration

### Environment Variables

```bash
export HENOTACE_API_KEY="your_api_key_here"
export HENOTACE_BASE_URL="https://api.djtconcept.ng"  # Optional
```

### SDK Configuration

```python
sdk = HenotaceAI(
    api_key="your_api_key",
    base_url="https://api.djtconcept.ng",  # Optional
    timeout=30,  # Request timeout in seconds
    retries=3    # Number of retries for failed requests
)

# Set default values
sdk.default_preset = "tutor_default"
sdk.default_persona = "You are a helpful tutor."
sdk.default_user_profile = {"grade": "high_school"}
```

## Error Handling

The SDK provides custom exceptions for different error types:

```python
from henotace_ai import HenotaceError, HenotaceAPIError, HenotaceNetworkError

try:
    response = await tutor.send("Hello!")
except HenotaceAPIError as e:
    print(f"API Error: {e}")
except HenotaceNetworkError as e:
    print(f"Network Error: {e}")
except HenotaceError as e:
    print(f"General Error: {e}")
```

## Examples

Check the `examples/` directory for more comprehensive examples:

- `basic_usage.py` - Basic SDK usage
- `advanced_features.py` - Context, personas, and profiles
- `custom_storage.py` - Custom storage connector
- `async_examples.py` - Async/await patterns
- `error_handling.py` - Error handling examples

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- Documentation: https://docs.henotace.ai/python-sdk
- Issues: https://github.com/henotace/henotace-python-sdk/issues
- Email: support@henotace.ai
