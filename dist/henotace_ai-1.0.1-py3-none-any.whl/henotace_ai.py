"""
Henotace AI SDK for Python
Official Python SDK for the Henotace AI API
"""

import requests
import json
import time
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class SessionSubject:
    """Subject information for tutoring sessions"""
    id: str
    name: str
    topic: str


@dataclass
class SessionChat:
    """Individual chat message in a session"""
    message: str
    is_reply: bool
    timestamp: Optional[int] = None


@dataclass
class SessionTutor:
    """Tutor information and chat history"""
    id: str
    name: str
    subject: SessionSubject
    chats: List[SessionChat] = None
    context: Optional[List[str]] = None
    persona: Optional[str] = None
    user_profile: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        if self.chats is None:
            self.chats = []
        if self.context is None:
            self.context = []


@dataclass
class SessionStudent:
    """Student information with associated tutors"""
    id: str
    name: Optional[str] = None
    tutors: List[SessionTutor] = None

    def __post_init__(self):
        if self.tutors is None:
            self.tutors = []


@dataclass
class ApiResponse:
    """Standard API response format"""
    success: bool
    data: Optional[Dict[str, Any]] = None
    message: Optional[str] = None
    timestamp: str = None


class HenotaceError(Exception):
    """Base exception for Henotace API errors"""
    pass


class HenotaceAPIError(HenotaceError):
    """API-specific errors"""
    pass


class HenotaceNetworkError(HenotaceError):
    """Network-related errors"""
    pass


class HenotaceAI:
    """
    Main client for interacting with the Henotace AI API
    """
    
    def __init__(self, api_key: str, base_url: str = "https://api.djtconcept.ng", 
                 timeout: int = 30, retries: int = 3):
        """
        Initialize the Henotace AI client
        
        Args:
            api_key: Your Henotace API key
            base_url: Base URL for the API (default: https://api.djtconcept.ng)
            timeout: Request timeout in seconds
            retries: Number of retries for failed requests
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.retries = retries
        
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'X-API-Key': self.api_key,
            'User-Agent': 'henotace-python-sdk/1.0.0'
        })
        
        # Default configuration
        self.default_persona = None
        self.default_preset = 'tutor_default'
        self.default_user_profile = None
        self.default_metadata = None

    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """
        Make an HTTP request with retry logic and error handling
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            **kwargs: Additional request parameters
            
        Returns:
            requests.Response object
            
        Raises:
            HenotaceNetworkError: For network-related errors
            HenotaceAPIError: For API-specific errors
        """
        url = f"{self.base_url}{endpoint}"
        
        for attempt in range(self.retries + 1):
            try:
                logger.info(f"[Henotace SDK] {method.upper()} {endpoint}")
                
                response = self.session.request(
                    method=method,
                    url=url,
                    timeout=self.timeout,
                    **kwargs
                )
                
                logger.info(f"[Henotace SDK] Response: {response.status_code} {response.reason}")
                
                # Handle rate limiting
                if response.status_code == 429:
                    retry_after = int(response.headers.get('retry-after', 60))
                    logger.info(f"[Henotace SDK] Rate limited. Waiting {retry_after} seconds")
                    time.sleep(retry_after)
                    continue
                
                # Handle server errors with retry
                if response.status_code >= 500 and attempt < self.retries:
                    wait_time = 2 ** attempt
                    logger.info(f"[Henotace SDK] Server error. Retrying in {wait_time} seconds (attempt {attempt + 1}/{self.retries})")
                    time.sleep(wait_time)
                    continue
                
                return response
                
            except requests.exceptions.RequestException as e:
                if attempt < self.retries:
                    wait_time = 2 ** attempt
                    logger.info(f"[Henotace SDK] Network error. Retrying in {wait_time} seconds (attempt {attempt + 1}/{self.retries})")
                    time.sleep(wait_time)
                    continue
                else:
                    raise HenotaceNetworkError(f"Network error: {str(e)}")

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """
        Handle API response and raise appropriate errors
        
        Args:
            response: requests.Response object
            
        Returns:
            Parsed response data
            
        Raises:
            HenotaceAPIError: For API-specific errors
        """
        try:
            data = response.json()
        except json.JSONDecodeError:
            raise HenotaceAPIError(f"Invalid JSON response: {response.text}")
        
        if response.status_code == 401:
            raise HenotaceAPIError("Invalid API key. Please check your credentials.")
        elif response.status_code == 429:
            raise HenotaceAPIError("Rate limit exceeded. Please try again later.")
        elif response.status_code >= 400:
            error_msg = data.get('error', f'HTTP {response.status_code} error')
            raise HenotaceAPIError(f"API error: {error_msg}")
        
        return data

    def get_status(self) -> Dict[str, Any]:
        """
        Check API status
        
        Returns:
            Status response data
        """
        try:
            response = self._make_request('GET', '/api/external/status/')
            return self._handle_response(response)
        except requests.exceptions.RequestException as e:
            if 'Network Error' in str(e):
                raise HenotaceNetworkError(f"Network Error: {str(e)}")
            raise

    def get_status_ok(self) -> bool:
        """
        Check if API is available (convenience method)
        
        Returns:
            True if API is available, False otherwise
        """
        try:
            status = self.get_status()
            return status.get('success', False) and status.get('data', {}).get('status') == 'ok'
        except:
            return False

    def complete_chat(self, history: List[Dict[str, str]], input_text: str, 
                     preset: str = None) -> Dict[str, str]:
        """
        Send a chat completion request to the API
        
        Args:
            history: List of conversation history messages
            input_text: User's input message
            preset: AI behavior preset (default: 'tutor_default')
            
        Returns:
            Dictionary containing the AI response
        """
        if preset is None:
            preset = self.default_preset
        
        payload = {
            'history': history,
            'input': input_text,
            'preset': preset
        }
        
        try:
            response = self._make_request(
                'POST', 
                '/api/external/working/chat/completion/',
                json=payload
            )
            data = self._handle_response(response)
            return {'ai_response': data.get('data', {}).get('ai_response', '')}
        except requests.exceptions.RequestException as e:
            logger.error(f"Chat completion error: {e}")
            raise


class StorageConnector:
    """
    Abstract base class for storage connectors
    """
    
    def get_all(self) -> Dict[str, List[SessionStudent]]:
        """Get all stored data"""
        raise NotImplementedError
    
    def set_all(self, schema: Dict[str, List[SessionStudent]]) -> None:
        """Set all data"""
        raise NotImplementedError
    
    def list_students(self) -> List[SessionStudent]:
        """List all students"""
        raise NotImplementedError
    
    def upsert_student(self, student: SessionStudent) -> None:
        """Create or update a student"""
        raise NotImplementedError
    
    def delete_student(self, student_id: str) -> None:
        """Delete a student"""
        raise NotImplementedError
    
    def list_tutors(self, student_id: str) -> List[SessionTutor]:
        """List tutors for a student"""
        raise NotImplementedError
    
    def upsert_tutor(self, student_id: str, tutor: SessionTutor) -> None:
        """Create or update a tutor"""
        raise NotImplementedError
    
    def delete_tutor(self, student_id: str, tutor_id: str) -> None:
        """Delete a tutor"""
        raise NotImplementedError
    
    def list_chats(self, student_id: str, tutor_id: str) -> List[SessionChat]:
        """List chats for a tutor"""
        raise NotImplementedError
    
    def append_chat(self, student_id: str, tutor_id: str, chat: SessionChat) -> None:
        """Add a chat message"""
        raise NotImplementedError
    
    def replace_chats(self, student_id: str, tutor_id: str, chats: List[SessionChat]) -> None:
        """Replace all chats for a tutor"""
        raise NotImplementedError


class InMemoryConnector(StorageConnector):
    """
    In-memory storage connector for testing and simple use cases
    """
    
    def __init__(self):
        self.storage = {'students': []}
    
    def get_all(self) -> Dict[str, List[SessionStudent]]:
        return self.storage
    
    def set_all(self, schema: Dict[str, List[SessionStudent]]) -> None:
        self.storage = schema
    
    def list_students(self) -> List[SessionStudent]:
        return self.storage.get('students', [])
    
    def upsert_student(self, student: SessionStudent) -> None:
        students = self.storage.get('students', [])
        existing_index = None
        
        for i, s in enumerate(students):
            if s.id == student.id:
                existing_index = i
                break
        
        if existing_index is not None:
            students[existing_index] = student
        else:
            students.append(student)
        
        self.storage['students'] = students
    
    def delete_student(self, student_id: str) -> None:
        students = self.storage.get('students', [])
        self.storage['students'] = [s for s in students if s.id != student_id]
    
    def list_tutors(self, student_id: str) -> List[SessionTutor]:
        students = self.storage.get('students', [])
        for student in students:
            if student.id == student_id:
                return student.tutors
        return []
    
    def upsert_tutor(self, student_id: str, tutor: SessionTutor) -> None:
        students = self.storage.get('students', [])
        
        for student in students:
            if student.id == student_id:
                # Update existing tutor or add new one
                existing_index = None
                for i, t in enumerate(student.tutors):
                    if t.id == tutor.id:
                        existing_index = i
                        break
                
                if existing_index is not None:
                    student.tutors[existing_index] = tutor
                else:
                    student.tutors.append(tutor)
                return
        
        # Student doesn't exist, create it
        new_student = SessionStudent(id=student_id, tutors=[tutor])
        students.append(new_student)
        self.storage['students'] = students
    
    def delete_tutor(self, student_id: str, tutor_id: str) -> None:
        students = self.storage.get('students', [])
        
        for student in students:
            if student.id == student_id:
                student.tutors = [t for t in student.tutors if t.id != tutor_id]
                return
    
    def list_chats(self, student_id: str, tutor_id: str) -> List[SessionChat]:
        tutors = self.list_tutors(student_id)
        for tutor in tutors:
            if tutor.id == tutor_id:
                return tutor.chats
        return []
    
    def append_chat(self, student_id: str, tutor_id: str, chat: SessionChat) -> None:
        tutors = self.list_tutors(student_id)
        for tutor in tutors:
            if tutor.id == tutor_id:
                tutor.chats.append(chat)
                self.upsert_tutor(student_id, tutor)
                return
        
        # Tutor doesn't exist, create it
        new_tutor = SessionTutor(
            id=tutor_id,
            name=tutor_id,
            subject=SessionSubject(id='unknown', name='Unknown', topic=''),
            chats=[chat]
        )
        self.upsert_tutor(student_id, new_tutor)
    
    def replace_chats(self, student_id: str, tutor_id: str, chats: List[SessionChat]) -> None:
        tutors = self.list_tutors(student_id)
        for tutor in tutors:
            if tutor.id == tutor_id:
                tutor.chats = chats
                self.upsert_tutor(student_id, tutor)
                return


class Tutor:
    """
    Lightweight Tutor instance for managing chat sessions
    """
    
    def __init__(self, sdk: HenotaceAI, student_id: str, tutor_id: str, 
                 storage: Optional[StorageConnector] = None):
        self.sdk = sdk
        self.student_id = student_id
        self.tutor_id = tutor_id
        self.storage = storage or InMemoryConnector()
        
        self.persistent_context = []
        self.persona = None
        self.user_profile = None
        self.metadata = None
        
        # Compression settings
        self.compression = {
            'max_turns': 12,
            'max_summary_chars': 1200,
            'checkpoint_every': 10
        }
    
    def set_context(self, context: Union[str, List[str]]) -> None:
        """Set persistent context for the tutor"""
        self.persistent_context = [context] if isinstance(context, str) else context
        
        # Persist to storage
        if self.storage:
            self._persist_to_storage()
    
    def set_persona(self, persona: str) -> None:
        """Set the tutor's persona"""
        self.persona = persona
        if self.storage:
            self._persist_to_storage()
    
    def set_user_profile(self, profile: Dict[str, Any]) -> None:
        """Set user profile information"""
        self.user_profile = profile
        if self.storage:
            self._persist_to_storage()
    
    def set_metadata(self, metadata: Dict[str, Any]) -> None:
        """Set metadata for the tutor"""
        self.metadata = metadata
        if self.storage:
            self._persist_to_storage()
    
    def set_compression(self, **options) -> None:
        """Configure compression settings"""
        self.compression.update(options)
    
    def _persist_to_storage(self) -> None:
        """Persist tutor data to storage"""
        try:
            tutors = self.storage.list_tutors(self.student_id)
            existing = None
            
            for t in tutors:
                if t.id == self.tutor_id:
                    existing = t
                    break
            
            if existing:
                # Update existing tutor
                existing.context = self.persistent_context
                existing.persona = self.persona
                existing.user_profile = self.user_profile
                existing.metadata = self.metadata
                self.storage.upsert_tutor(self.student_id, existing)
            else:
                # Create new tutor
                new_tutor = SessionTutor(
                    id=self.tutor_id,
                    name=self.tutor_id,
                    subject=SessionSubject(id='unknown', name='Unknown', topic=''),
                    context=self.persistent_context,
                    persona=self.persona,
                    user_profile=self.user_profile,
                    metadata=self.metadata
                )
                self.storage.upsert_tutor(self.student_id, new_tutor)
        except Exception as e:
            logger.warning(f"Failed to persist tutor data: {e}")
    
    def _build_summary_from_chats(self, chats: List[SessionChat], max_chars: int) -> str:
        """Build a summary from chat history"""
        lines = []
        for chat in chats:
            sender = 'AI' if chat.is_reply else 'User'
            lines.append(f"{sender}: {chat.message}")
        
        summary = '\n'.join(lines)
        if len(summary) > max_chars:
            summary = summary[:max_chars - 3] + '...'
        
        return summary
    
    def _auto_compress_if_needed(self) -> None:
        """Auto-compress chat history if needed"""
        if not self.storage:
            return
        
        chats = self.storage.list_chats(self.student_id, self.tutor_id)
        if not chats:
            return
        
        should_checkpoint = len(chats) % self.compression['checkpoint_every'] == 0
        exceeds_window = len(chats) > self.compression['max_turns'] * 2
        
        if should_checkpoint or exceeds_window:
            self.compress_history()
    
    def compress_history(self) -> None:
        """Compress chat history by summarizing older messages"""
        if not self.storage:
            return
        
        chats = self.storage.list_chats(self.student_id, self.tutor_id)
        if not chats:
            return
        
        keep = self.compression['max_turns']
        if len(chats) <= keep:
            return
        
        # Keep recent messages, summarize older ones
        older_chats = chats[:-keep]
        recent_chats = chats[-keep:]
        
        summary_chunk = self._build_summary_from_chats(older_chats, self.compression['max_summary_chars'])
        
        # Update tutor metadata with summary
        tutors = self.storage.list_tutors(self.student_id)
        existing = None
        for t in tutors:
            if t.id == self.tutor_id:
                existing = t
                break
        
        if existing:
            existing_meta = existing.metadata or {}
            accumulated = existing_meta.get('summary', '')
            if accumulated:
                accumulated += f"\n---\n{summary_chunk}"
            else:
                accumulated = summary_chunk
            
            existing.metadata = {**existing_meta, 'summary': accumulated}
            self.storage.upsert_tutor(self.student_id, existing)
        
        # Replace chats with recent ones only
        self.storage.replace_chats(self.student_id, self.tutor_id, recent_chats)
    
    async def send(self, message: str, context: Optional[Union[str, List[str]]] = None, 
                  preset: Optional[str] = None) -> str:
        """
        Send a message to the tutor and get AI response
        
        Args:
            message: User's message
            context: Optional ephemeral context
            preset: Optional AI preset
            
        Returns:
            AI response text
        """
        # Build history from storage
        history = []
        if self.storage:
            self._auto_compress_if_needed()
            chats = self.storage.list_chats(self.student_id, self.tutor_id)
            history = [
                {'role': 'assistant' if chat.is_reply else 'user', 'content': chat.message}
                for chat in chats
            ]
        
        # Add ephemeral context
        ephemeral = [context] if isinstance(context, str) else (context or [])
        merged_context = self.persistent_context + ephemeral
        
        if merged_context:
            clipped = merged_context[:5]  # Simple budget: top 5 snippets
            context_block = '\n'.join(['[CONTEXT]'] + [str(sn) for sn in clipped])
            history.append({'role': 'assistant', 'content': context_block})
        
        # Add persona, user profile, and metadata as context
        sdk_config = self.sdk.__dict__
        persona = self.persona or sdk_config.get('default_persona')
        user_profile = self.user_profile or sdk_config.get('default_user_profile')
        metadata = self.metadata or sdk_config.get('default_metadata')
        
        header_parts = []
        if persona:
            header_parts.append(f"[PERSONA] {persona}")
        if user_profile:
            header_parts.append(f"[USER] {json.dumps(user_profile)[:1000]}")
        if metadata:
            header_parts.append(f"[META] {json.dumps(metadata)[:1000]}")
        
        if header_parts:
            history.append({'role': 'assistant', 'content': '\n'.join(header_parts)})
        
        # Get AI response
        completion = self.sdk.complete_chat(
            history=history,
            input_text=message,
            preset=preset or sdk_config.get('default_preset', 'tutor_default')
        )
        
        ai_response = completion.get('ai_response', '')
        
        # Store in session history
        if self.storage:
            now = int(time.time() * 1000)
            user_chat = SessionChat(message=message, is_reply=False, timestamp=now)
            self.storage.append_chat(self.student_id, self.tutor_id, user_chat)
            
            if ai_response:
                ai_chat = SessionChat(message=ai_response, is_reply=True, timestamp=now + 1)
                self.storage.append_chat(self.student_id, self.tutor_id, ai_chat)
        
        return ai_response
    
    def history(self) -> List[SessionChat]:
        """Get chat history for this tutor"""
        if not self.storage:
            return []
        return self.storage.list_chats(self.student_id, self.tutor_id)
    
    @property
    def ids(self) -> Dict[str, str]:
        """Get student and tutor IDs"""
        return {'student_id': self.student_id, 'tutor_id': self.tutor_id}


async def create_tutor(sdk: HenotaceAI, student_id: str, tutor_name: str = None, 
                      subject: SessionSubject = None, grade_level: str = None,
                      language: str = None, storage: Optional[StorageConnector] = None) -> Tutor:
    """
    Factory function to create a new tutor
    
    Args:
        sdk: HenotaceAI SDK instance
        student_id: Unique student identifier
        tutor_name: Optional tutor name
        subject: Optional subject information
        grade_level: Optional grade level
        language: Optional language preference
        storage: Optional storage connector
        
    Returns:
        Configured Tutor instance
    """
    tutor_id = tutor_name or f"tutor_{int(time.time())}"
    storage = storage or InMemoryConnector()
    
    # Ensure storage entries
    try:
        storage.upsert_student(SessionStudent(id=student_id))
        storage.upsert_tutor(student_id, SessionTutor(
            id=tutor_id,
            name=tutor_name or tutor_id,
            subject=subject or SessionSubject(id='general', name='General', topic='')
        ))
    except Exception as e:
        logger.warning(f"Failed to initialize storage: {e}")
    
    # Create tutor instance
    tutor = Tutor(sdk, student_id, tutor_id, storage)
    
    # Load any previously saved context
    try:
        tutors = storage.list_tutors(student_id)
        existing = None
        for t in tutors:
            if t.id == tutor_id:
                existing = t
                break
        
        if existing and existing.context:
            tutor.set_context(existing.context)
    except Exception as e:
        logger.warning(f"Failed to load tutor context: {e}")
    
    # Set initial context based on parameters
    if grade_level or language or (subject and subject.topic):
        meta = []
        if language:
            meta.append(f"Language: {language}")
        if grade_level:
            meta.append(f"Grade Level: {grade_level}")
        if subject and subject.topic:
            meta.append(f"Topic: {subject.topic}")
        
        if meta:
            tutor.set_context(meta)
    
    return tutor


# Export main classes and functions
__all__ = [
    'HenotaceAI', 'Tutor', 'StorageConnector', 'InMemoryConnector',
    'SessionStudent', 'SessionTutor', 'SessionChat', 'SessionSubject',
    'HenotaceError', 'HenotaceAPIError', 'HenotaceNetworkError',
    'create_tutor'
]
